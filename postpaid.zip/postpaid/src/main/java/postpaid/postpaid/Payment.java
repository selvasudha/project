package postpaid.postpaid;

import lombok.Data;
import org.hibernate.validator.constraints.CreditCardNumber;

import javax.validation.constraints.Digits;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
@Data
public class Payment {
        @NotBlank
        @Size(min = 5,message = "Atleast 5 characters")
        private String owner;
        @NotBlank
        @Digits(integer=3,message="Invalid no", fraction = 0)
        private String cvv;
        @NotBlank
        @CreditCardNumber
        private String cardno;
}


